<?php
$connection = mysqli_connect('localhost', 'root', '','grocery');
if (!$connection){
    die("Database Connection Failed"); //. mysqli_connect_error());
}
//$select_db = mysqli_select_db($connection, 'grocery');
//if (!$select_db){
 //   die("Database Selection Failed" . mysqli_error($connection));
//}
?>